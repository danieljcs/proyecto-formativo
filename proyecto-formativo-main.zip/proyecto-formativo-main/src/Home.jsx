//import { useState } from 'react'
//import { useState } from 'react'
import React from 'react';
import Aside from './_aside';

const Home = () => {
  return (
    <>
      <div className='h-screen flex'>
        <Aside />
        <div className='flex flex-col mx-auto w-2/3'>
          <div className='w-full h-1/4 flex flex-row justify-between items-center p-4 bg-purple-500 text-white rounded'>
            <div>
              <p className='text-sm mb-2'>septiembre, 2023</p>
              <h1 className='text-2xl font-bold'>
                Bienvenido Coordinador
              </h1>
            </div>
            <img
              src='tangara triguera.jpeg'
              alt='Imagen de Bienvenida'
              className='w-100 h-100 rounded-full ml-6'
            />
          </div>
          <br />
          <br />
          <br />
          <br />
          <br />
          <br />

          {/* Nuevo contenedor único */}
          <div className='flex mt-4'>
            <div className='bg-gray-300 p-4 rounded-md flex flex-col mx-auto w-80 h-45'>
              <h2 className='text-2xl font-bold mb-4'>Título:</h2>
              <div className='flex flex-col mx-auto w-40'>
                {/* Gráfica de barra morada para Título 1 */}
                <div className='bg-purple-600 h-4 w-full rounded'></div>
                <br />
                <div className='bg-purple-600 h-4 w-full rounded'></div>
                <br />
                <div className='bg-purple-600 h-4 w-full rounded'></div>
              </div>
            </div>

            <div className='bg-gray-300 p-4 rounded-md flex flex-col mx-auto w-80 h-45 ml-4'>
              <h2 className='text-2xl font-bold mb-4'>Título:</h2>
              <div className='flex flex-col mx-auto w-40'>
                {/* Gráfica de barra morada para Título 1 */}
                <div className='bg-purple-600 h-4 w-full rounded'></div>
                <br />
                <div className='bg-purple-600 h-4 w-full rounded'></div>
                <br />
                <div className='bg-purple-600 h-4 w-full rounded'></div>
              </div>
            </div>
            </div>
            </div>
            </div>

       
            
    </>
  );
};

export default Home;









