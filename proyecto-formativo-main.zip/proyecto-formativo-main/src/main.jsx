import React from 'react'
import ReactDOM from 'react-dom/client'
import './assets/css/index.css'
import {  RouterProvider, createBrowserRouter } from 'react-router-dom'
// import { Route } from 'react-router-dom'
import Home from './Home.jsx'
//import _aside from './_aside.jsx'

import Horario from './horario.jsx'
import Asignaturas from './asignaturas.jsx'
import Formulario from './inicioSesion.jsx'
import Gestionaru from './gestionaru.jsx'
import Asistencias  from './asistencia.jsx'
import ObservadorEstudiante  from './observadoEst.jsx'



const router = createBrowserRouter([
{
path:"/login",
element :<Formulario/>
},

{
  path:"/Home",
  element :<Home/>
},
{
    path:"/Horario",
    element :<Horario/>
},
{
    path:"/Asignaturas",
    element :<Asignaturas/>
},
{
  path:"/gestionaru",
  element :<Gestionaru/>
},
{
  path:"/asistencia",
  element :<Asistencias/>
},
{
  path:"/observa1",
  element :<ObservadorEstudiante/>
},



])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    
    <RouterProvider   router ={router}/>
  </React.StrictMode>,
)