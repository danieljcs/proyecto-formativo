

import React, { useState } from 'react';
import Aside from './_aside';

const Asistencias = () => {
  const [matricula, setMatricula] = useState(28);
  const [asistencias, setAsistencias] = useState({
    presente: 28,
    retardos: 0,
    ausencias: 0,
  });

  const obtenerFechaActual = () => {
    const fecha = new Date();
    const dia = fecha.getDate();
    const mes = fecha.getMonth() + 1;
    const año = fecha.getFullYear();
    return `${dia}/${mes}/${año}`;
  };

  return (
    <div className='flex h-screen bg-[#A6DCF1]'>
      <Aside />

      <div className='ml-4 p-4 w-full overflow-y-auto text-white'>
        {/* Buscador */}
        <div>
          <input type='text' placeholder='Buscar...' className='border p-2 rounded' />
        </div>

        {/* Información de fecha y perfil del usuario en el lado derecho */}
        <div className=' flex items-center mt-2 justify-end'>
          <div className='text-right'>
            <p className='text-black mr-4 text-lg'>{obtenerFechaActual()}</p>
            <h5 className='text-2xl font-bold text-indigo-700 mb-2 text-black'>¡Bienvenido!</h5>
          </div>
        </div>

        {/* Container con información sobre el lenguaje */}
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Lenguaje 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>

        {/* Repite este bloque según sea necesario */}
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Matemáticas 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Nurales 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Ciencias Sociales 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Estadisticas 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Fisica 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>
        <div className='mt-4 p-8 bg-gradient-to-r from-indigo-400 to-indigo-800 rounded'>
          <h2 className='text-5xl font-bold mb-4 tracking-wider'>Quimica 3°A</h2>
          <div className='flex items-center justify-between'>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Matrícula: {matricula}</p>
              <br />
              <p className='ml-4 rounded text-lg'>Presente: {asistencias.presente}</p>
            </div>
            <div className='flex items-center'>
              <p className='rounded text-lg'>Presente con retardos: {asistencias.retardos}</p>
              <p className='ml-4 rounded text-lg'>Ausente: {asistencias.ausencias}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Asistencias;
