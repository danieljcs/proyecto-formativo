import React, { useState } from 'react';

const ObservadorEstudiante = () => {
  const [fecha] = useState(new Date().toLocaleDateString());
  const [pagina, setPagina] = useState('Observado del Estudiante');
  const [gradoSeleccionado, setGradoSeleccionado] = useState('');
  const [nuevoAspecto, setNuevoAspecto] = useState('');
  const [aspectos, setAspectos] = useState([
    '01-Atención y motivación',
    '02-Respeto',
    '03-Mala convivencia',
    '04-Cooperación',
    '05-Responsabilidad',
  ]);
  const [cursoSeleccionado, setCursoSeleccionado] = useState('');
  const [nuevoCriterioCodigo, setNuevoCriterioCodigo] = useState('');
  const [nuevoCriterioDescripcion, setNuevoCriterioDescripcion] = useState('');
  const [criterios, setCriterios] = useState([
    { curso: 'Curso 1', codigo: '01', descripcion: 'Demuestra la capacidad de liderazgo' },
    { curso: 'Curso 2', codigo: '02', descripcion: 'Muestra respeto hacia los demás' },
  ]);

  const agregarAspecto = () => {
    if (nuevoAspecto) {
      setAspectos([...aspectos, nuevoAspecto]);
      setNuevoAspecto('');
    }
  };

  const eliminarAspecto = (index) => {
    const nuevosAspectos = [...aspectos];
    nuevosAspectos.splice(index, 1);
    setAspectos(nuevosAspectos);
  };

  const agregarCriterio = () => {
    if (cursoSeleccionado && nuevoCriterioCodigo && nuevoCriterioDescripcion) {
      setCriterios([
        ...criterios,
        { curso: cursoSeleccionado, codigo: nuevoCriterioCodigo, descripcion: nuevoCriterioDescripcion },
      ]);
      setNuevoCriterioCodigo('');
      setNuevoCriterioDescripcion('');
    }
  };

  const eliminarCriterio = (index) => {
    const nuevosCriterios = [...criterios];
    nuevosCriterios.splice(index, 1);
    setCriterios(nuevosCriterios);
  };

  return (
    <div style={{ backgroundColor: '#A6DCF1', color: 'white', minHeight: '100vh', padding: '16px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      {/* Barra superior */}
      <div style={{ backgroundColor: 'indigo', padding: '8px', display: 'flex', justifyContent: 'space-between', width: '100%' }}>
        <span onClick={() => setPagina('')}>
          {pagina && (
            <button style={{ borderRadius: '10px', padding: '8px', background: 'none', border: 'none', cursor: 'pointer', color: 'black', fontSize: '14px' }}>
              {'<'}
            </button>
          )}
        </span>
        <h2>{pagina}</h2>
        <span>{fecha}</span>
      </div>

      {/* Contenido principal */}
      {pagina === 'Observado del Estudiante' && (
        <div style={{ marginTop: '26px', width: '80%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          {/* Botones de Observación y Registro de Criterios */}
          <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: '16px', width: '60%' }}>
            <button style={{ borderRadius: '10px', padding: '8px', background: 'none', border: '1px solid white', color: 'black', width: '30%', fontSize: '26px' }}>Observación</button>
            <button style={{ borderRadius: '10px', padding: '8px', background: 'none', border: '1px solid white', color: 'black', width: '30%', fontSize: '26px' }}>Registro de Criterios</button>
          </div>

          {/* Container Registro de Aspectos */}
          <div style={{ border: '1px solid white', borderRadius: '10px', padding: '16px', marginBottom: '86px', maxWidth: '600px', width: '100%' }}>
            <h3 style={{ color: 'black', marginBottom: '8px' }}>Registro de Aspectos</h3>
            <div style={{ display: 'flex', marginBottom: '20px', width: '100%' }}>
              <select
                onChange={(e) => setGradoSeleccionado(e.target.value)}
                value={gradoSeleccionado}
                style={{ marginRight: '8px', width: '30%', color: 'black' }}
              >
                <option value="">Seleccionar Grado</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
              </select>
              <input
                type="text"
                placeholder="Nuevo Aspecto"
                value={nuevoAspecto}
                onChange={(e) => setNuevoAspecto(e.target.value)}
                style={{ marginRight: '1px', width: '50%', color: 'black' }}
              />
              <button
                onClick={agregarAspecto}
                style={{ borderRadius: '10px', padding: '8px', background: 'indigo', color: 'black', width: '20%', fontSize: '12px' }}
              >
                +Agregar
              </button>
            </div>
            <ul style={{ paddingInlineStart: '20px', marginBottom: '8px', color: 'black' }}>
              {aspectos.map((aspecto, index) => (
                <li key={index} style={{ marginBottom: '4px', display: 'flex', justifyContent: 'space-between' }}>
                  <span>{aspecto}</span>
                  <button
                    onClick={() => eliminarAspecto(index)}
                    style={{ borderRadius: '10px', padding: '4px', background: 'red', color: 'white', fontSize: '12px' }}
                  >
                    Eliminar
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Container Registro de Criterios */}
          <div style={{ border: '1px solid white', borderRadius: '10px', padding: '16px', marginBottom: '16px', maxWidth: '600px', width: '100%' }}>
            <h3 style={{ color: 'black', marginBottom: '8px' }}>Registro de Criterios por Aspecto</h3>
            <div style={{ display: 'flex', marginBottom: '8px', width: '100%' }}>
              <input
                type="text"
                placeholder="Curso"
                value={cursoSeleccionado}
                onChange={(e) => setCursoSeleccionado(e.target.value)}
                style={{ marginRight: '8px', width: '30%', color: 'black' }}
              />
              <input
                type="text"
                placeholder="Nuevo Criterio"
                value={nuevoCriterioDescripcion}
                onChange={(e) => setNuevoCriterioDescripcion(e.target.value)}
                style={{ marginRight: '8px', width: '50%', color: 'black' }}
              />
              <button
                onClick={agregarCriterio}
                style={{ borderRadius: '10px', padding: '8px', background: 'indigo', color: 'black', width: '20%', fontSize: '12px' }}
              >
                Agregar
              </button>
            </div>
            <ul style={{ paddingInlineStart: '20px', marginBottom: '8px', color: 'black' }}>
              {criterios.map((criterio, index) => (
                <li key={index} style={{ marginBottom: '4px', display: 'flex', justifyContent: 'space-between' }}>
                  <strong>{criterio.codigo}</strong>: {criterio.descripcion}
                  <button
                    onClick={() => eliminarCriterio(index)}
                    style={{ borderRadius: '10px', padding: '4px', background: 'red', color: 'white', fontSize: '12px' }}
                  >
                    Eliminar
                  </button>
                </li>
              ))}
            </ul>
            <button
              style={{ borderRadius: '10px', padding: '8px', background: 'a883c0', color: 'white', marginTop: '8px', marginLeft: 'auto', display: 'block' }}
            >
              Guardar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ObservadorEstudiante;
